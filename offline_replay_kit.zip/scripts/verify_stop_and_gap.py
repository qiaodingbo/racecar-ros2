from collections import Counter
import json
import math
from pathlib import Path
import sys
from types import ModuleType, SimpleNamespace

import numpy as np

root = Path(sys.argv[1]).resolve()
sys.path[:0] = [str(root), str(root/'core'), str(root/'planners/dense')]

def fake(name, **attrs):
    mod = ModuleType(name)
    vars(mod).update(attrs)
    sys.modules[name] = mod

class Publisher:
    def publish(self, msg):
        pass

    def get_subscription_count(self):
        return 1

class Node:
    def __init__(self, name):
        pass

    def create_subscription(self, *args):
        pass

    def create_timer(self, *args):
        pass

    def create_publisher(self, *args):
        return Publisher()

    def count_publishers(self, topic):
        return 1

    def get_logger(self):
        return SimpleNamespace(info=lambda _: None, error=lambda _: None)

def twist():
    return SimpleNamespace(linear=SimpleNamespace(x=0.),angular=SimpleNamespace(z=0.))

fake('rclpy')
fake('rclpy.node', Node=Node)
fake('rclpy.qos', QoSProfile=lambda **_: None, ReliabilityPolicy=SimpleNamespace(BEST_EFFORT=0))
fake('rclpy.signals', SignalHandlerOptions=object)
fake('geometry_msgs.msg', Twist=twist)
fake('nav_msgs.msg', Odometry=object)
fake('sensor_msgs.msg', Imu=object, LaserScan=object)
import dense_s_bend as drive
from dense_reference import DenseRoute
from geometry import scan_geometry, swept_clearance

settings = json.loads((root/'dense_settings.json').read_text(encoding='utf8'))
clock = 0.
drive.time.monotonic = lambda: clock
drive.RunRecorder = lambda *_: SimpleNamespace(append=lambda _: None,path='offline')
drive.DenseSBend.code_revision = staticmethod(lambda: {})

def install_scan(node, now, stamp, pose, cones, points):
    node.scan_at, node.scan_pose = now, pose
    node.frames.append(dict(stamp=stamp))
    node.scan_id += 1
    node.cones, node.points = cones, points

def tick(node, now, speed, distance):
    global clock
    clock = now
    node.imu_at = node.encoder_at = clock
    node.speed, node.distance = speed, distance
    node.control()
    return node.events[-1] if node.events and node.events[-1]['kind']=='command' else None

def pose(x):
    return dict(x_m=x,y_m=0.,yaw_rad=0.,segment=0)

def straight_route():
    x = np.linspace(-.4,2.5,40)
    centers = np.column_stack((x,np.zeros(len(x))))
    return DenseRoute(centers,centers+[0.,.75],centers-[0.,.75],centers,0,1.5,
                      np.zeros(len(x)),.9,(.9,0.),0.,False)

def obstacle(x):
    return np.column_stack((np.full(5,x),np.linspace(-.012,.012,5)))

def warm(speed):
    global clock
    clock = 10.
    node = drive.DenseSBend(settings)
    state = dict(valid=True)
    def plan(*args, **kwargs):
        p = node.planner
        p.last_pair = dict(width_min=1.5,at_car=0.,supported_ahead_m=2.5) if state['valid'] else None
        p.reject = None if state['valid'] else 'missing_side'
        return straight_route() if state['valid'] else None
    node.planner.plan = plan
    for i in range(42):
        now = 10.+(i+1)*.05
        if i%2==0:
            install_scan(node,now,(0,i+1),pose(0.),np.empty((0,2)),np.empty((0,2)))
        tick(node,now,speed if node.ever_drove else 0.,0.)
    assert node.ever_drove and node.last_pwm>1500
    return node,state

def gap_case(speed):
    node, state = warm(speed)
    now = clock
    old = node.events[-1]
    pwm,servo,target = old['pwm'],old['servo'],old['target_mps']
    state['valid'] = False
    install_scan(node,now+.05,(1,1),pose(speed*.1),np.empty((0,2)),np.empty((0,2)))
    first = tick(node,now+.05,speed,speed*.05)
    second_tick = tick(node,now+.10,speed,speed*.10)
    assert first['pwm']==second_tick['pwm']==pwm and first['servo']==second_tick['servo']==servo
    assert first['target_mps']==second_tick['target_mps']==target
    assert first['pair_missing_frames']==second_tick['pair_missing_frames']==1
    assert first['clearance_state']=='single_pair_gap' and node.obstacle.holding_since is None
    install_scan(node,now+.15,(1,2),pose(speed*.2),np.empty((0,2)),np.empty((0,2)))
    second_scan = tick(node,now+.15,speed,speed*.15)
    assert second_scan['pair_missing_frames']==2 and second_scan['target_mps']<target
    assert second_scan['pwm']>1500 and node.obstacle.holding_since is None
    for i in range(4,15):
        t=now+i*.05
        if i%2==1:
            install_scan(node,t,(1,i+2),pose(speed*i*.05),np.empty((0,2)),np.empty((0,2)))
        tick(node,t,speed,speed*i*.05)
        if node.stop_reason:
            break
    assert node.stop_reason=='cone_corridor_lost' and node.pwm==1500
    print('gap',speed,'initial and single-gap PWM',round(pwm,2),round(first['pwm'],2),
          'second scan target',round(target,2),'->',round(second_scan['target_mps'],2),
          'sustained loss',round(clock-now,2),'s')

    records=trace_single_gap(speed)
    assert records[1]['pwm']==records[0]['pwm'] and records[-1]['pwm']>1500
    assert records[-1]['pair_missing_frames']==0
    print('single gap and recovery',speed,'PWM',np.round([r['pwm'] for r in records],2).tolist())

def trace_single_gap(speed):
    node,state=warm(speed)
    now=clock
    before=node.events[-1]
    state['valid']=False
    install_scan(node,now+.05,(1,1),pose(.05*speed),np.empty((0,2)),np.empty((0,2)))
    missed=tick(node,now+.05,speed,.05*speed)
    between=tick(node,now+.10,speed,.10*speed)
    state['valid']=True
    install_scan(node,now+.15,(1,2),pose(.15*speed),np.empty((0,2)),np.empty((0,2)))
    recovered=tick(node,now+.15,speed,.15*speed)
    assert node.obstacle.holding_since is None
    return [before,missed,between,recovered]

def obstacle_cases():
    for distance, expected in ((1.48,'slowing_for_obstacle'), (1.34,'coasting_for_obstacle'),
                               (1.20,'obstacle_in_stopping_distance')):
        node, state = warm(1.)
        now = clock+.05
        install_scan(node,now,(1,1),pose(.05),np.empty((0,2)),obstacle(distance))
        result = tick(node,now,1.,.05)
        assert result['clearance_state']==expected, result
        assert math.isclose(result['obstacle_distance_m'],distance-.455,abs_tol=.002), result
        if expected=='slowing_for_obstacle':
            assert result['pwm']>1500
        else:
            assert result['pwm']==1500
        assert (node.obstacle.holding_since is not None)==(expected=='obstacle_in_stopping_distance')
        print('obstacle raw x',distance,'nose travel',round(result['obstacle_distance_m'],3),expected)
    node, state = warm(1.)
    state['valid']=False
    now=clock+.05
    install_scan(node,now,(1,1),pose(.05),np.empty((0,2)),obstacle(.75))
    result=tick(node,now,1.,.05)
    assert result['pwm']==1500 and result['clearance_state']=='obstacle_during_pair_gap'
    print('obstacle on first lost frame',result['clearance_state'])

def simulated_wall():
    node,_=warm(2.)
    now=clock
    speed,position=2.,0.
    wall_x=4.65
    history=[]
    for i in range(200):
        t=now+(i+1)*.05
        if i%2==0:
            install_scan(node,t,(2,i+1),pose(position),np.empty((0,2)),obstacle(wall_x-position))
        result=tick(node,t,speed,position)
        speed_target=node.speed_pi.target if result['pwm']>1500 else 0.
        a=float(np.clip(2.*(speed_target-speed),-drive.COAST_DECEL,.5))
        next_speed=max(0.,speed+a*.05)
        position+=(speed+next_speed)*.025
        speed=next_speed
        clearance=wall_x-node.car.front-node.car.margin-position
        history.append(dict(t=t-now,speed=speed,clearance=clearance,state=result['clearance_state'],
                            pwm=result['pwm']))
        assert clearance>0., history[-1]
    assert speed<.06 and history[-1]['pwm']==1500.
    print('2 m/s simulated wall stop',round(history[-1]['clearance'],3),'m to padded nose')
    Path('obstacle_stop_simulation.json').write_text(json.dumps(history,indent=2),encoding='utf8')

def replay(path):
    global clock
    rows = list(map(json.loads,Path(path).open(encoding='utf8')))
    scans = [s for s in rows if s['kind']=='scan']
    plans = {e['scan_id']: e for e in rows if e['kind']=='dense_plan'}
    end = next((e['at'] for e in rows if e['kind']=='test_stop_requested'),rows[-1]['at'])
    clock=scans[0]['at']-.05
    node=drive.DenseSBend(settings)
    node.ever_drove=True
    node.first_move_at=clock-5.
    node.obstacle.clear_frames=3
    counts=Counter()
    last=None
    for s in scans:
        if s['at']>end:
            break
        plan=plans.get(s['scan_id'])
        if not plan or not s['pose']:
            continue
        _,points=scan_geometry(s['ranges'],s['angle_min'],s['angle_increment'],s['range_min'],s['range_max'],
                               rows[0]['lidar_in_axle'],True)
        now=plan['at']
        if last is None:
            node.last_tick=now-.05
            node.ever_drove=False
        install_scan(node,now,s['stamp'],s['pose'],np.array(plan['cones']).reshape(-1,2),points)
        result=tick(node,now,plan['speed'],plan['distance'])
        if result and node.ever_drove:
            state=result['clearance_state']
            counts[state,result['pwm']>1500] += 1
        if node.stop_reason:
            break
        last=now
    print(Path(path).name,dict(counts),'end',node.stop_reason,round(node.distance,2))

if __name__=='__main__':
    if hasattr(drive,'obstacle_stop_distance'):
        for speed in (1.6,2.):
            gap_case(speed)
        obstacle_cases()
        simulated_wall()
        for v in (.47,.86,1.05,1.17,1.6,2.):
            print('thresholds',v,round(drive.obstacle_stop_distance(v),2),
                  round(drive.obstacle_stop_distance(v)+drive.BRAKE_REACTION*v,2))
    output = next((arg.split('=',1)[1] for arg in sys.argv[2:] if arg.startswith('--trace=')),None)
    if output:
        records=trace_single_gap(2.)
        Path(output).write_text(json.dumps(records,indent=2),encoding='utf8')
    for path in (arg for arg in sys.argv[2:] if not arg.startswith('--trace=')):
        replay(path)
