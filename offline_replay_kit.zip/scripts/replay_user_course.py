from collections import Counter
import json
import math
from pathlib import Path
import sys
from time import perf_counter
from types import SimpleNamespace

import numpy as np

root = Path(sys.argv[1]).resolve()
sys.path[:0] = [str(root/'core'), str(root/'planners/dense')]
from geometry import relative_to_path, scan_geometry
from pairing import PairPlanner
from progressive import ProgressivePlanner

settings = json.loads((root/'dense_settings.json').read_text())
car = SimpleNamespace(width=1.5, radius=.83, front=.40, rear=.16, half_width=.175,
                      margin=.055, laser_x=.23)
class DebugPlanner(ProgressivePlanner):
    def _route(self, pair, left, right, speed, reference, raw_points):
        result = super()._route(pair, left, right, speed, reference, raw_points)
        if result is None and self.reject == 'handoff_discontinuity' and '--debug' in sys.argv:
            route = PairPlanner._route(self, pair, left, right, speed, reference, raw_points)
            if route is None:
                return result
            x = route.centers[:, 0]
            common = (x >= reference[0, 0]) & (x <= reference[-1, 0]) & (x <= 1.40)
            overlap = route.centers[common]
            lateral, tangent = relative_to_path(overlap, reference)
            delta = np.diff(overlap, axis=0)
            angle = np.arctan2(delta[:,1], delta[:,0])
            old_angle = np.arctan2(tangent[:-1,1], tangent[:-1,0])
            print('reject', event['scan_id'], np.round(reference[[0,-1]], 2).tolist(),
                  np.round(route.centers[[0,-1]], 2).tolist(), len(overlap),
                  np.round(lateral, 2).tolist(), np.round(np.degrees(angle-old_angle), 1).tolist(),
                  np.round(right.points, 2).tolist())
        return result


planner = DebugPlanner(car, settings)
records = list(map(json.loads, Path(sys.argv[2]).open(encoding='utf8')))
scans = {e['scan_id']: e for e in records if e['kind']=='scan'}
start_id = int(sys.argv[3]) if len(sys.argv) > 3 else 0
old = None
counts = Counter()
times = []
for event in (e for e in records if e['kind']=='dense_plan' and e['scan_id'] >= start_id):
    scan = scans[event['scan_id']]
    _, raw = scan_geometry(scan['ranges'], scan['angle_min'], scan['angle_increment'],
                           scan['range_min'], scan['range_max'], records[0]['lidar_in_axle'], True)
    pose = scan['pose']
    reference = None
    if old and pose and event['at']-old[0] <= .5 and pose['segment'] == old[1]['segment']:
        _, before, path = old
        xy = np.array([pose['x_m']-before['x_m'], pose['y_m']-before['y_m']])
        def rot(angle):
            return np.array([[math.cos(angle), -math.sin(angle)], [math.sin(angle), math.cos(angle)]])
        reference = (path @ rot(before['yaw_rad']).T - xy) @ rot(pose['yaw_rad'])
    start = perf_counter()
    route = planner.plan(event['cones'], event['speed'], event['at'], reference, raw, pose,
                         tuple(scan['stamp']))
    times.append((perf_counter()-start)*1000)
    corner = planner.corner.event
    state = corner['state'] if corner else planner.reject if route is None else 'pair'
    recovered = (planner.last_pair or {}).get('opposite_side_recovery', False)
    counts[state] += 1
    counts['recovered'] += recovered
    if route is not None:
        old = event['at'], pose, route.centers
    if recovered or event['scan_id'] >= 108 or state == 'exit_reacquired' or '--all' in sys.argv:
        print(event['scan_id'], round(event['distance'], 3), state, recovered,
              None if route is None else (np.round(route.right, 2).tolist(), np.round(route.target, 3).tolist()),
              round(times[-1], 1))
print(counts, 'planning ms p95/max', np.round(np.percentile(times, [95, 100]), 2))
