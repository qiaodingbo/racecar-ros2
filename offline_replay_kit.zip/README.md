# 小车本地回放与模拟

`vehicle/` 是从车载归档提取的实测版源码和配置。最后一次实跑的日志记录了 10 个代码及配置文件的 SHA-256，已经逐个与 `vehicle/` 核对。`candidate/` 在这套源码上保留了两处后续修正，分别调整右后轮附近的扫掠余量，以及检查短重叠新旧路线的端点位置和方向。候选修正通过了原始日志回放，尚待实车验证。

## 本地运行

解压后在本目录打开 PowerShell，使用已安装 NumPy 的 Python。下面三个脚本用本地日志和模拟输入运行。`run_user_course.py` 是车上实测使用的监护脚本，随包保存供对照。

```powershell
$journal = 'logs/20261112_212001_drive_op9zcbzp.jsonl'
py scripts/measure_stop_live.py $journal
py scripts/replay_user_course.py vehicle $journal
py scripts/replay_user_course.py candidate $journal
py scripts/verify_stop_and_gap.py candidate $journal
```

最后一条命令执行实际控制代码的本地测试，模拟单帧和持续丢线、前方障碍及 2.0 m/s 的滑行停车。该命令会在当前目录生成 `obstacle_stop_simulation.json`。日志回放使用记录时的雷达和位姿。停车模拟采用简化的纵向滑行模型，后续实车路径和高速转弯能力仍需实测。

## 最后一次实测

`logs/20261112_212001_drive_op9zcbzp.jsonl` 包含 129 帧雷达数据，每帧都有对应位姿。小车在 3.48 m 完成直角弯出口接力，累计航向变化约 94.5°。10.32 m 处单帧失配时油门和舵角保持原值，连续三帧接续失败后在 10.77 m 切空挡，12.71 m 停稳。`logs/` 还保存了其他五份用于对照的记录。

`manifest.json` 记录实测版文件、候选修改文件和最新日志的校验值。完整车载归档另存于同一备份目录下的 `racecar_car_snapshot.tar.gz`。
