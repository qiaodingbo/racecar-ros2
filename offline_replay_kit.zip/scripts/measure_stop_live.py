from collections import Counter
import json
import math
from pathlib import Path
import sys

import numpy as np

events=list(map(json.loads,Path(sys.argv[1]).open(encoding='utf8')))
plans=[e for e in events if e['kind']=='dense_plan']
commands=[e for e in events if e['kind']=='command']
scans=[e for e in events if e['kind']=='scan']
print('journal',events[-1],'scans',len(scans),'poses',sum(e['pose'] is not None for e in scans),
      'planning ms',np.percentile([p['plan_ms'] for p in plans],[50,95,100]).round(2).tolist())
for e in events:
    if e['kind'].startswith('test_'):
        print(e)
print('plans',Counter(p['reject'] for p in plans),'corner',Counter((p.get('corner') or {}).get('state') for p in plans))
print('encoder peak',round(max(s['speed_mps'] for s in scans),3))
corner=[p['speed'] for p in plans if (p.get('corner') or {}).get('state')=='turning']
if corner:
    print('turning min/median/max',np.percentile(corner,[0,50,100]).round(3).tolist())
motion=[i for i,e in enumerate(commands) if e['pwm']>1500.01]
if motion:
    drive=commands[motion[0]:motion[-1]+1]
    print('drive states',Counter((e.get('clearance_state'),e['pwm']>1500.01) for e in drive))
    holds=[]
    start=None
    for i,e in enumerate(drive):
        if e['pwm']<=1500.01 and start is None:
            start=i
        if e['pwm']>1500.01 and start is not None:
            seconds=e['at']-drive[start]['at']
            p=min(plans,key=lambda p:abs(p['at']-drive[start]['at']))
            holds.append((round(p['distance'],3),round(seconds,3),
                          dict(Counter(q.get('clearance_state') for q in drive[start:i]))))
            start=None
    print('neutral intervals during drive',holds)
    for i,e in enumerate(drive):
        if e.get('clearance_state')=='single_pair_gap' and (i==0 or drive[i-1].get('clearance_state')!='single_pair_gap'):
            j=i+1
            while j<len(drive) and drive[j].get('clearance_state')=='single_pair_gap':
                j+=1
            p=min(plans,key=lambda p:abs(p['at']-e['at']))
            print('single gap at',round(p['distance'],3),'m speed',round(e['speed_mps'],3),
                  'PWM pre/gap/post',[round(q['pwm'],2) for q in drive[max(0,i-1):j+1]],
                  'servo',[round(q['servo'],2) for q in drive[max(0,i-1):j+1]])
    for e in drive:
        if e.get('clearance_state') in ('obstacle_in_stopping_distance','obstacle_during_pair_gap'):
            p=min(plans,key=lambda p:abs(p['at']-e['at']))
            print('hard raw at',round(p['distance'],3),'m',e.get('obstacle_distance_m'),
                  'vs',e.get('obstacle_stop_distance_m'),'at',e['speed_mps'])
for p in plans[-8:]:
    rv=p.get('revalidation') or {}
    print('tail',p['scan_id'],round(p['distance'],3),p['reject'],p.get('row_stats'),
          rv.get('near_confirmed'),rv.get('far_visible'))
