import os
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.conditions import IfCondition
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from launch.launch_description_sources import PythonLaunchDescriptionSource
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    racecar_share_dir = get_package_share_directory('racecar')
    encoder_driver_share_dir = get_package_share_directory('encoder_driver')

    return LaunchDescription([
        DeclareLaunchArgument(
            'use_rviz',
            default_value='false',
            description='Whether to start RViz'
        ),
        DeclareLaunchArgument(
            'init_x',
            default_value='0.0',
            description='Initial X position for AMCL'
        ),
        DeclareLaunchArgument(
            'init_y',
            default_value='0.0',
            description='Initial Y position for AMCL'
        ),
        DeclareLaunchArgument(
            'init_a',
            default_value='0.0',
            description='Initial orientation for AMCL'
        ),

        # Static transforms
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='map_to_odom',
            arguments=['0.0', '0.0', '0.0', '0', '0', '0.0', 'map', 'odom', '1000']
        ),
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='base_to_laser',
            arguments=['0.0', '0.0', '0.0', '0', '0', '0.0', 'base_link', 'laser', '1000']
        ),

        # Map server
        Node(
            package='nav2_map_server',
            executable='map_server',
            name='map_server',
            output='screen',
            parameters=[{'yaml_filename': os.path.join(racecar_share_dir, 'map', 'ceshi1.yaml')}]
        ),

        # Include rf2o_Laser_Odometry
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(racecar_share_dir, 'launch',  'rf2o_laser_odometry.launch.py')
            )
        ),

        # Include wheel odometry
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(encoder_driver_share_dir, 'launch', 'wheel_odom.launch.py')
            )
        ),

        # Robot Localization
        Node(
            package='robot_localization',
            executable='ekf_node',
            name='ekf_se',
            output='screen',
            parameters=[os.path.join(racecar_share_dir, 'param', 'ekf_params.yaml')],
        ),

        # Include AMCL
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(racecar_share_dir, 'launch', 'includes', 'amcl.launch.py')
            ),
            launch_arguments={
                'init_x': LaunchConfiguration('init_x'),
                'init_y': LaunchConfiguration('init_y'),
                'init_a': LaunchConfiguration('init_a')
            }.items()
        ),

        # Move base
        Node(
            package='nav2_bt_navigator',
            executable='bt_navigator',
            name='move_base',
            output='screen',
            parameters=[
                os.path.join(racecar_share_dir, 'param', 'dwa_local_planner_params.yaml'),
                os.path.join(racecar_share_dir, 'param', 'local_costmap_params.yaml'),
                os.path.join(racecar_share_dir, 'param', 'global_costmap_params.yaml'),
                os.path.join(racecar_share_dir, 'param', 'base_global_planner_params.yaml'),
                os.path.join(racecar_share_dir, 'param', 'move_base_params.yaml'),
            ],
            remappings=[
                ('/odom', '/odometry/filtered')
            ]
        ),

        # Racecar controller
        Node(
            package='racecar',
            executable='car_controller_new',
            name='car_controller',
            output='screen',
            parameters=[{
                'Vcmd': 1.0,
                'baseSpeed': 150,
                'baseAngle': 0.0,
                'Angle_gain_p': -3.0,
                'Angle_gain_d': -3.0,
                'Lfw': 1.5,
                'vp_max_base': 300,
                'vp_min': 380,
            }]
        ),

        # RViz
        Node(
            package='rviz2',
            executable='rviz2',
            name='rviz2',
            arguments=['-d', os.path.join(racecar_share_dir, 'rviz', 'amcl.rviz')],
            condition=IfCondition(LaunchConfiguration('use_rviz'))
        ),
    ])