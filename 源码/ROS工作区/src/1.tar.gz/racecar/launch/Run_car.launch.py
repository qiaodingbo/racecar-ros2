from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from launch.substitutions import LaunchConfiguration
import os
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    # 获取包共享目录
    racecar_share_dir = get_package_share_directory('racecar')
    lslidar_x10_driver_share_dir = get_package_share_directory('lslidar_x10_driver')
    imu_launch_share_dir = get_package_share_directory('imu_launch')
    
    # 声明参数
    imu_package_arg = DeclareLaunchArgument(
        'imu_package', default_value='spec',
        description='package type [spec,0x91]'
    )

    return LaunchDescription([
        imu_package_arg,

        # Include TF setting
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(racecar_share_dir, 'launch', 'includes', 'car_tf.launch.xml')
            )
        ),

        # Include Lidar launch
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(lslidar_x10_driver_share_dir, 'launch', 'lslidar_x10_serial.launch')
            )
        ),

        # Include IMU launch
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(imu_launch_share_dir, 'launch', f'imu_{LaunchConfiguration("imu_package")}_msg.launch')
            )
        ),

        # Racecar Driver Node
        Node(
            package='racecar_driver',
            executable='racecar_driver_node',
            name='racecar_driver',
            output='screen'
        ),

        # Encoder Driver Node
        Node(
            package='encoder_driver',
            executable='Encoder_vel.py',
            name='encoder_vel',
            output='screen',
            parameters=[
                {'serial_port': '/dev/encoder'},
                {'k': 0.88},
                {'baud_rate': 57600}
            ]
        ),

        # Rosbridge Server Node
        Node(
            package='rosbridge_server',
            executable='rosbridge_websocket',
            name='rosbridge_server',
            output='screen'
        )
    ])

